<?php
class Filter
{
	static function bug1508()
	{
		/* Should not show up */
		$foo = 1;	
	}
}

